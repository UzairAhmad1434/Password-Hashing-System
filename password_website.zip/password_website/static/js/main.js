/* ── State ── */
var lastHash = '';
var lastAlgo = '';
var lastSalt = '';
var strengthTimer = null;

/* ── Navigation ── */
function show(id, btn) {
  document.querySelectorAll('.section').forEach(s => s.classList.remove('active'));
  document.querySelectorAll('.nav-btn').forEach(b => b.classList.remove('active'));
  document.getElementById(id).classList.add('active');
  btn.classList.add('active');
  if (id === 'compare') buildChart();
}

/* ── Eye Toggle ── */
function toggleEye() {
  var inp = document.getElementById('h-pass');
  var btn = document.getElementById('eye-btn');
  inp.type = inp.type === 'password' ? 'text' : 'password';
  btn.innerHTML = inp.type === 'text' ? '<i class="ti ti-eye-off"></i>' : '<i class="ti ti-eye"></i>';
}

/* ── Hash Password ── */
async function hashPassword() {
  var password = document.getElementById('h-pass').value.trim();
  var algo = document.getElementById('h-algo').value;
  var useSalt = document.getElementById('use-salt').checked;

  if (!password) { showError('h-error', 'Please enter a password first.'); return; }

  document.getElementById('h-loading').style.display = 'flex';
  document.getElementById('h-error').style.display = 'none';
  document.getElementById('h-result-card').style.display = 'none';

  try {
    var res = await fetch('/api/hash', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ password, algorithm: algo, use_salt: useSalt })
    });
    var data = await res.json();

    if (data.error) { showError('h-error', data.error); return; }

    lastHash = data.hash;
    lastAlgo = algo;
    lastSalt = data.salt || '';

    var algoColors = { md5:'#ef4444', sha256:'#eab308', sha512:'#f97316', pbkdf2:'#22c55e', bcrypt:'#10b981', argon2:'#6366f1' };
    var algoLabels = { md5:'MD5 ⚠️', sha256:'SHA-256 ⚠️', sha512:'SHA-512 ⚠️', pbkdf2:'PBKDF2 ✅', bcrypt:'bcrypt ✅', argon2:'Argon2id ✅' };

    document.getElementById('h-algo-badge').innerHTML = `<span class="badge" style="background:rgba(0,0,0,.3);color:${algoColors[algo]};border:1px solid ${algoColors[algo]}40">${algoLabels[algo]}</span>`;
    document.getElementById('h-hash').textContent = data.hash;
    document.getElementById('h-time').innerHTML = `<i class="ti ti-clock"></i> Hashed in <strong style="color:#a5b4fc">${data.time_ms} ms</strong>`;

    var saltRow = document.getElementById('h-salt-row');
    if (data.salt && data.salt !== 'built-in') {
      saltRow.innerHTML = `<div style="font-size:11px;color:#64748b;font-family:'Courier New',monospace">Salt: ${data.salt}</div>`;
    } else if (data.salt === 'built-in') {
      saltRow.innerHTML = `<div style="font-size:11px;color:#64748b">Salt: built-in (embedded in hash)</div>`;
    } else {
      saltRow.innerHTML = '';
    }

    document.getElementById('v-result').innerHTML = '';
    document.getElementById('h-result-card').style.display = 'block';

  } catch (e) {
    showError('h-error', 'Server error. Make sure Flask is running.');
  } finally {
    document.getElementById('h-loading').style.display = 'none';
  }
}

function clearHash() {
  document.getElementById('h-pass').value = '';
  document.getElementById('h-result-card').style.display = 'none';
  document.getElementById('h-error').style.display = 'none';
  lastHash = ''; lastAlgo = ''; lastSalt = '';
}

function copyHash() {
  if (!lastHash) return;
  navigator.clipboard.writeText(lastHash).catch(() => {});
}

async function verifyHash() {
  var password = document.getElementById('h-pass').value.trim();
  if (!password || !lastHash) return;

  var el = document.getElementById('v-result');
  el.innerHTML = '<span style="color:#64748b;font-size:13px">Verifying...</span>';

  try {
    var res = await fetch('/api/verify', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ password, hash: lastHash, algorithm: lastAlgo, salt: lastSalt })
    });
    var data = await res.json();
    if (data.match) {
      el.innerHTML = `<div class="msg-success"><i class="ti ti-circle-check"></i> Verified! Hash matches — login would succeed. (${data.time_ms}ms)</div>`;
    } else {
      el.innerHTML = `<div class="msg-error"><i class="ti ti-circle-x"></i> Mismatch — access denied. (${data.time_ms}ms)</div>`;
    }
  } catch (e) {
    el.innerHTML = '<div class="msg-error">Verification failed — server error.</div>';
  }
}

function showError(id, msg) {
  var el = document.getElementById(id);
  el.style.display = 'flex';
  el.innerHTML = `<i class="ti ti-alert-circle"></i> ${msg}`;
}

/* ── Strength Checker ── */
function setAndCheck(pw) {
  document.getElementById('s-pass').value = pw;
  checkStrength();
}

async function checkStrength() {
  clearTimeout(strengthTimer);
  strengthTimer = setTimeout(async () => {
    var pw = document.getElementById('s-pass').value;
    if (!pw) {
      document.getElementById('s-result').innerHTML = '';
      document.getElementById('s-bar').style.width = '0%';
      return;
    }
    try {
      var res = await fetch('/api/strength', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ password: pw })
      });
      var d = await res.json();
      renderStrength(d);
    } catch (e) {}
  }, 200);
}

function renderStrength(d) {
  var colors = ['#ef4444','#ef4444','#f97316','#eab308','#22c55e','#22c55e','#10b981','#10b981','#6366f1'];
  var pct = Math.round((d.score / d.max) * 100);
  var bar = document.getElementById('s-bar');
  bar.style.width = pct + '%';
  bar.style.background = colors[Math.min(d.score, 8)];

  var col = colors[Math.min(d.score, 8)];
  var html = `<div style="display:flex;align-items:center;gap:12px;margin-bottom:16px;flex-wrap:wrap">
    <span style="font-size:20px;font-weight:700;color:${col}">${d.strength}</span>
    <span class="badge" style="background:rgba(255,255,255,.07);color:#94a3b8;border-color:#2d3748">Score: ${d.score}/8</span>
    <span class="badge" style="background:rgba(255,255,255,.07);color:#94a3b8;border-color:#2d3748">Entropy: ~${d.entropy} bits</span>
    <span class="badge" style="background:rgba(255,255,255,.07);color:#94a3b8;border-color:#2d3748">Length: ${d.length}</span>
  </div>`;

  if (d.good && d.good.length) {
    d.good.forEach(g => { html += `<div style="font-size:13px;color:#34d399;margin-bottom:5px;display:flex;align-items:center;gap:6px"><i class="ti ti-check"></i>${g}</div>`; });
  }
  if (d.feedback && d.feedback.length) {
    html += '<div style="margin-top:8px">';
    d.feedback.forEach(f => { html += `<div style="font-size:13px;color:#f87171;margin-bottom:5px;display:flex;align-items:center;gap:6px"><i class="ti ti-alert-circle"></i>${f}</div>`; });
    html += '</div>';
  }
  document.getElementById('s-result').innerHTML = html;
}

/* ── Algorithm Compare ── */
var algoData = [
  { name: 'MD5',      speed: 1764521, color: '#ef4444', badge: 'badge-danger',  label: 'Critical' },
  { name: 'SHA-256',  speed: 326442,  color: '#f97316', badge: 'badge-danger',  label: 'Weak'     },
  { name: 'SHA-512',  speed: 212000,  color: '#eab308', badge: 'badge-warning', label: 'Weak'     },
  { name: 'PBKDF2',   speed: 13,      color: '#22c55e', badge: 'badge-success', label: 'Good'     },
  { name: 'bcrypt',   speed: 3,       color: '#10b981', badge: 'badge-success', label: 'Strong'   },
  { name: 'Argon2id', speed: 6,       color: '#6366f1', badge: 'badge-info',    label: 'Best'     },
];

function buildAlgoList() {
  var maxLog = Math.log10(algoData[0].speed);
  var html = algoData.map(a => {
    var pct = Math.max(Math.round((Math.log10(a.speed) / maxLog) * 100), 2);
    return `<div class="algo-row">
      <div class="algo-name">${a.name}</div>
      <div class="speed-track"><div class="speed-fill" style="width:${pct}%;background:${a.color}"></div></div>
      <div class="algo-speed">${a.speed.toLocaleString()} h/s</div>
      <div class="algo-badge"><span class="badge ${a.badge}">${a.label}</span></div>
    </div>`;
  }).join('');
  document.getElementById('algo-list').innerHTML = html;
}

var chartBuilt = false;
function buildChart() {
  buildAlgoList();
  if (chartBuilt) return;
  chartBuilt = true;
  new Chart(document.getElementById('algoChart'), {
    type: 'bar',
    data: {
      labels: algoData.map(a => a.name),
      datasets: [{
        label: 'Hashes per second',
        data: algoData.map(a => a.speed),
        backgroundColor: algoData.map(a => a.color + 'cc'),
        borderColor: algoData.map(a => a.color),
        borderWidth: 1,
        borderRadius: 6
      }]
    },
    options: {
      responsive: true, maintainAspectRatio: false,
      plugins: {
        legend: { display: false },
        tooltip: { callbacks: { label: c => ' ' + c.parsed.y.toLocaleString() + ' hashes/sec' } }
      },
      scales: {
        y: {
          type: 'logarithmic',
          ticks: { color: '#64748b', callback: v => v >= 1000000 ? (v/1000000).toFixed(1)+'M' : v >= 1000 ? Math.round(v/1000)+'K' : v },
          grid: { color: 'rgba(255,255,255,.05)' }
        },
        x: { ticks: { color: '#94a3b8', autoSkip: false }, grid: { display: false } }
      }
    }
  });
}

/* ── Attack Demos ── */
function genFakeHash(seed) {
  var h = '';
  var chars = '0123456789abcdef';
  for (var i = 0; i < 40; i++) {
    var idx = (seed.charCodeAt(i % seed.length) + i * 7) % 16;
    h += chars[idx];
  }
  return h;
}

function rainbowAttack() {
  var el = document.getElementById('r1');
  el.textContent = '[*] Loading rainbow table...';
  setTimeout(() => {
    el.textContent =
`[*] Target: MD5 hash of password "password"
    Hash: 5f4dcc3b5aa765d61d8327deb882cf99

[*] Searching rainbow table (7 sample entries)...
    5f4dcc3b... → "password"   ← FOUND!
    e10adc39... → "123456"
    d8578edf... → "qwerty"
    21232f29... → "admin"

[!!!] CRACKED in 0.001ms!
      Password: "password"

[*] Real rainbow tables have BILLIONS of entries.
[*] Same input = same MD5 hash every time.
[*] Conclusion: Never use unsalted MD5!`;
  }, 700);
}

function dictAttack() {
  var el = document.getElementById('r2');
  var words = ['password','123456','qwerty','admin','football','iloveyou','letmein','monkey','dragon','trustno1'];
  el.textContent = '[*] Starting dictionary attack...';
  var i = 0;
  var iv = setInterval(() => {
    if (i >= words.length) {
      clearInterval(iv);
      el.textContent =
`[*] Wordlist loaded: 10 common passwords

[-] "password"  → no match
[-] "123456"    → no match
[-] "qwerty"    → no match
[-] "admin"     → no match
[!] "football"  → MATCH FOUND!

[!!!] CRACKED: "football" in 5 attempts, 0.02ms

[*] Real attackers use lists with 10 MILLION+ words.
[*] Conclusion: Never use common words as passwords!`;
      return;
    }
    el.textContent = `[*] Trying: "${words[i]}"...`;
    i++;
  }, 130);
}

function saltDefense() {
  var s1 = Math.random().toString(36).substring(2, 18).toUpperCase();
  var s2 = Math.random().toString(36).substring(2, 18).toUpperCase();
  var h1 = genFakeHash('password' + s1);
  var h2 = genFakeHash('password' + s2);
  document.getElementById('r3').textContent =
`[*] Same password "password", two different users:

    User A — Salt: ${s1}
    User A — Hash: ${h1}

    User B — Salt: ${s2}
    User B — Hash: ${h2}

[✓] Completely different hashes!
[✓] An attacker's rainbow table is now USELESS.
    A new table would need to be built per salt.
    With 128-bit salts: 2^128 possible tables!

[✓] Salting makes every hash unique.
[✓] Conclusion: Always salt every password!`;
}

function bcryptDemo() {
  document.getElementById('r4').textContent =
`[*] Comparing hashing speeds (attacker's view):

    MD5:
    → CPU speed : 1,764,521 hashes/second
    → GPU speed : ~164,000,000,000 hashes/sec
    → 8-char crack: minutes to hours

    bcrypt (cost = 12):
    → CPU speed : ~3 hashes/second
    → GPU speed : ~180,000 hashes/sec (memory bound!)
    → 8-char crack: 100+ years

    Argon2id (m=64MB, t=3):
    → CPU speed : ~6 hashes/second
    → GPU speed : < 1,000 hashes/sec (needs 64MB RAM each!)
    → 8-char crack: 1,000+ years

[✓] Slow + memory-hard = practically uncrackable.
[✓] Conclusion: Use bcrypt or Argon2id for passwords!`;
}

function timingDemo() {
  document.getElementById('r5').textContent =
`[*] Timing Attack Demonstration:

    VULNERABLE — naive string comparison:
    if stored_hash == entered_hash:  ← stops at first mismatch!

    "abc1234" vs "abcXXXX" → stops at pos 4 (takes 4ns)
    "1234567" vs "abcXXXX" → stops at pos 1 (takes 1ns)

    Attacker times many requests:
    → Short time = mismatch early = wrong start chars
    → Long time = mismatch late = correct prefix found!
    → Can reconstruct hash byte-by-byte!

    SAFE — constant-time comparison:
    hmac.compare_digest(stored_hash, entered_hash)
    → Always compares ALL bytes regardless of mismatch
    → Same time for "aaa" vs "zzz" every time
    → Zero timing information leaked

[✓] Python's hmac.compare_digest() used in this project.
[✓] Conclusion: Always use constant-time comparison!`;
}

/* ── Init ── */
buildAlgoList();
