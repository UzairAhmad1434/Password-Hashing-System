from flask import Flask, render_template, request, jsonify
import hashlib, bcrypt, secrets, hmac, base64, time
from argon2 import PasswordHasher
from argon2.exceptions import VerifyMismatchError

app = Flask(__name__)

# ── Routes ──────────────────────────────────────
@app.route('/')
def index():
    return render_template('index.html')

@app.route('/api/hash', methods=['POST'])
def api_hash():
    data     = request.json
    password = data.get('password', '')
    algo     = data.get('algorithm', 'bcrypt')
    use_salt = data.get('use_salt', True)

    if not password:
        return jsonify({'error': 'Password required'}), 400

    salt = secrets.token_hex(16) if use_salt else ''
    start = time.perf_counter()

    try:
        if algo == 'md5':
            h = hashlib.md5((salt + password).encode()).hexdigest()
            result = {'hash': h, 'salt': salt}

        elif algo == 'sha256':
            h = hashlib.sha256((salt + password).encode()).hexdigest()
            result = {'hash': h, 'salt': salt}

        elif algo == 'sha512':
            h = hashlib.sha512((salt + password).encode()).hexdigest()
            result = {'hash': h, 'salt': salt}

        elif algo == 'pbkdf2':
            dk = hashlib.pbkdf2_hmac('sha256', password.encode(), salt.encode(), 260000)
            result = {'hash': 'pbkdf2$260000$' + salt + '$' + base64.b64encode(dk).decode(), 'salt': salt}

        elif algo == 'bcrypt':
            h = bcrypt.hashpw(password.encode(), bcrypt.gensalt(rounds=12))
            result = {'hash': h.decode(), 'salt': 'built-in'}

        elif algo == 'argon2':
            ph = PasswordHasher(time_cost=3, memory_cost=65536, parallelism=2)
            result = {'hash': ph.hash(password), 'salt': 'built-in'}

        else:
            return jsonify({'error': 'Unknown algorithm'}), 400

        elapsed = round((time.perf_counter() - start) * 1000, 2)
        result['time_ms'] = elapsed
        result['algorithm'] = algo
        return jsonify(result)

    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/api/verify', methods=['POST'])
def api_verify():
    data      = request.json
    password  = data.get('password', '')
    hash_str  = data.get('hash', '')
    algo      = data.get('algorithm', 'bcrypt')
    salt      = data.get('salt', '')

    start = time.perf_counter()
    try:
        if algo == 'md5':
            test = hashlib.md5((salt + password).encode()).hexdigest()
            match = hmac.compare_digest(test, hash_str)

        elif algo == 'sha256':
            test = hashlib.sha256((salt + password).encode()).hexdigest()
            match = hmac.compare_digest(test, hash_str)

        elif algo == 'sha512':
            test = hashlib.sha512((salt + password).encode()).hexdigest()
            match = hmac.compare_digest(test, hash_str)

        elif algo == 'pbkdf2':
            parts = hash_str.split('$')
            stored_salt = parts[2]
            dk = hashlib.pbkdf2_hmac('sha256', password.encode(), stored_salt.encode(), 260000)
            test = 'pbkdf2$260000$' + stored_salt + '$' + base64.b64encode(dk).decode()
            match = hmac.compare_digest(test, hash_str)

        elif algo == 'bcrypt':
            match = bcrypt.checkpw(password.encode(), hash_str.encode())

        elif algo == 'argon2':
            ph = PasswordHasher()
            try:
                match = ph.verify(hash_str, password)
            except VerifyMismatchError:
                match = False
        else:
            match = False

        elapsed = round((time.perf_counter() - start) * 1000, 2)
        return jsonify({'match': match, 'time_ms': elapsed})

    except Exception as e:
        return jsonify({'error': str(e), 'match': False}), 500


@app.route('/api/strength', methods=['POST'])
def api_strength():
    import re
    password = request.json.get('password', '')
    score = 0
    feedback = []
    good = []

    if len(password) >= 8:   score += 1
    else: feedback.append('Too short — minimum 8 characters')
    if len(password) >= 12:  score += 1
    if len(password) >= 16:  score += 1; good.append(f'Great length ({len(password)} chars)')
    if re.search(r'[A-Z]', password): score += 1; good.append('Has uppercase letters')
    else: feedback.append('Add uppercase letters (A-Z)')
    if re.search(r'[a-z]', password): score += 1; good.append('Has lowercase letters')
    else: feedback.append('Add lowercase letters (a-z)')
    if re.search(r'\d', password): score += 1; good.append('Has numbers')
    else: feedback.append('Add numbers (0-9)')
    if re.search(r'[!@#$%^&*(),.?":{}|<>]', password): score += 2; good.append('Has special characters')
    else: feedback.append('Add special characters (!@#$...)')

    common = ['password','123456','qwerty','admin','letmein','abc123','monkey','dragon','iloveyou']
    if password.lower() in common:
        score = 0; feedback = ['This is one of the most commonly used passwords!']

    labels = ['Very Weak','Very Weak','Weak','Moderate','Good','Good','Strong','Strong','Very Strong']
    return jsonify({
        'score': score,
        'max': 8,
        'strength': labels[min(score, 8)],
        'entropy': round(len(password) * 6.5, 1),
        'feedback': feedback,
        'good': good,
        'length': len(password)
    })


if __name__ == '__main__':
    print("\n  🔐 Password Hashing System")
    print("  ─────────────────────────────")
    print("  Running at: http://127.0.0.1:5000")
    print("  Press Ctrl+C to stop\n")
    app.run(debug=True, port=5000)
